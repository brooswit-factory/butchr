# Codex MCP events

`CodexAppServerRunner` owns a persistent `codex app-server` process over stdio.
The first message starts or resumes one native thread. Later messages use that
same thread; restarting the runner requires the caller's persisted thread ID.
The runner serializes turns, checks thread and turn identities, and refuses to
retry after an acknowledgement timeout or a broken connection. The host must
close it during shutdown and persist returned conversation identities.

The runner requests `on-request` approvals with Codex's `auto_review` reviewer.
This keeps approval review available for unattended MCP calls. It does not
grant requests itself, and unsupported interactive requests fail closed. The
installed Codex must support these App Server fields. Workspace access remains
controlled by the supplied permission mode.

`startMcpChannelProxy` uses one upstream Streamable HTTP MCP connection for both
normal tools and `notifications/claude/channel` events. Its authenticated
loopback endpoint can be configured as the Codex MCP server. Sharing the
connection avoids competing clients claiming the same server-side identity.
Provide the returned URL and headers only to the owned agent. Credentials and
event contents must not be logged by the host.

Pass incoming events to `InboxRelay`, then to the host's existing message entry
point. This preserves the host's conversation serialization. Incoming content
is rendered as external data. A busy host is retried; an uncertain acceptance
pauses delivery instead of risking a duplicate turn. Queue overflow drops the
oldest waiting event, never the in-flight event. The queue is bounded and held
in memory; it is not a durable event log or an exactly-once delivery guarantee.

This is an opt-in owned runtime, currently integrated into USRR. It does not
attach to an arbitrary existing Codex process, alter the Claude launcher, or
register a task in the Codex desktop app. Desktop voice visibility requires a
separate integration.
