# Windows native transcript reader

Windows x64 uses Bun FFI to open each pathname component relative to a pinned
parent handle (`NtCreateFile.RootDirectory`). It opens reparse points themselves
and refuses every reparse tag, including symlinks and junctions. Directory
searches enumerate the pinned handle with `GetFileInformationByHandleEx`.
Reading and metadata checks use that same handle. Renaming a parent and replacing
it with a junction therefore cannot redirect a pending child open.

Only drive-absolute paths are accepted. UNC/device namespaces, alternate data
streams, parent traversal, DOS device aliases, and trailing dot/space aliases are
rejected before opening. Other platforms retain their previous refusal; Linux
retains its `/proc/self/fd` implementation. Windows ARM64 is not supported yet.
The drive-root mapping is the trust anchor, as `/` is on Linux. This is a
no-symlink reader, not a directory allowlist or protection against hard links.
Windows filesystem ACLs remain the caller's access-control boundary.

The implementation requires Bun's Windows FFI support. Failure to load native
APIs fails closed; there is no ordinary-path fallback. Production adoption must
also validate the consuming application's packaging and history/handoff tests.

Validation on Windows x64, Bun 1.3.11: 15 tests pass, including actual file and
parent symlinks, junction replacement after pinning, handle enumeration,
Codex/Claude/AGY reads, malformed UTF-8, size limits, and search bounds.
Linux: 433 pass, two Windows-only tests skipped; typecheck and package build pass.

References:
- https://learn.microsoft.com/en-us/windows/win32/api/winternl/nf-winternl-ntcreatefile
- https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-getfileinformationbyhandleex
- https://learn.microsoft.com/en-us/windows/win32/api/winbase/ns-winbase-file_id_both_dir_info
- https://bun.sh/docs/runtime/ffi

For a copied Codex session, `expectedSessionCwd` can specify the exact original
session_meta.cwd without interpreting it as a path on the new OS. This option
only applies to Codex ID discovery. The caller must persist it in protected
migration metadata bound to the particular provider and session ID, and supply
it only for that identity. New sessions use the current runtime cwd by default.
ID, header cwd, filename, duplicate and safe-read checks remain in force. Do not
infer this binding from arbitrary candidate transcripts or rewrite their header.
Updated validation: 434 Linux tests pass, 16 native Windows package tests pass.

Codex ID discovery profile precedence: explicit `codexHome`, explicit
`home/.codex`, ambient nonempty `CODEX_HOME`, then `homedir()/.codex`. This keeps
explicit home fixtures deterministic while allowing a dedicated resident profile.
Profile paths must be absolute without parent traversal and are walked using the
same safe reader. A symlinked profile is refused. Latest checks: 435 Linux tests,
17 native Windows built-package tests, typecheck and build pass.

`maxBytes` configures a whole-file read cap: default 4 MiB, positive integer up
to 64 MiB. A resident can explicitly select 32 MiB for larger history. Oversized
files are refused, never truncated; exact-cap files are accepted. Allocation is
bounded by observed file size plus one byte; before/after size/time checks remain.
Claude incremental tail chunks retain their existing 4 MiB bound. Latest checks:
436 Linux tests, 18 native Windows built-package tests, typecheck/build pass.
