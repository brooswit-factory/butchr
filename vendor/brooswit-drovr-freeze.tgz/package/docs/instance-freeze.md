# Instance freeze

Freeze is a persistent operator override, independent of host desired state and idle sleeping. A frozen instance may remain desired-on, but must not run or wake. Thaw removes the veto; the host still decides whether to run it. Ownership and staffing rules are not changed.

Use the CLI under the same OS user and control-root environment as the host:

```
drovr-instance freeze 'candlestix:@agent-id'
drovr-instance status 'candlestix:@agent-id'
drovr-instance unfreeze 'candlestix:@agent-id'
```

Host identities are `candlestix:<durable agent ID>`, `bakr:<durable agent ID>`, and `butchr:<resource agent key>`. Use actual stored IDs, not display names or directories. Multiple Bakr agents can share a directory.

State lives at `$XDG_STATE_HOME/drovr/control` (default `~/.local/state/drovr/control`) on Linux, or `%LOCALAPPDATA%\drovr\control` on Windows. `DROVR_CONTROL_HOME` overrides it with an absolute directory. Keep that value consistent between control commands and services. State survives host restarts and provider switches. This is a same-user scheduling control, not a security boundary against programs running as that user.

A freeze command acknowledges persisted intent, not verified process exit. Running managed instances observe changes via a one-second watcher or the host's reconciliation cycle; stopping a native process can take longer. Hosts refuse new starts and prompt delivery while frozen. Unknown/corrupt control state fails closed. Check host process status to confirm shutdown. Freezing stops execution and preserves stored conversation identity/history, but does not promise replay of in-memory pending events or completion of an interrupted action.

Library hosts pass `instanceId` to the managed lifecycle/Codex runner, use `instanceFreezeStore.assertRunnable` before starts, and enforce the same override for adopted processes in reconciliation. `watchInstanceFreeze` supports a host stop callback; keep it installed until stop succeeds. Callbacks must target only that instance and preserve history. Call `close()` on watchers once their runtime is retired. Freeze opt-in does not affect other instances or legacy clients that do not supply an identity.
